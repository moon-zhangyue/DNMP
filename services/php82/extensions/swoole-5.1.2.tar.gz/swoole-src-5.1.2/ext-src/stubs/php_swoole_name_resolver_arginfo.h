/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: 385775b8664fb0cfc035bfc26fb762885cb77aa8 */

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Swoole_NameResolver_Context___construct, 0, 0, 0)
	ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, family, IS_LONG, 0, "AF_INET")
	ZEND_ARG_TYPE_INFO_WITH_DEFAULT_VALUE(0, withPort, _IS_BOOL, 0, "false")
ZEND_END_ARG_INFO()


ZEND_METHOD(Swoole_NameResolver_Context, __construct);


static const zend_function_entry class_Swoole_NameResolver_Context_methods[] = {
	ZEND_ME(Swoole_NameResolver_Context, __construct, arginfo_class_Swoole_NameResolver_Context___construct, ZEND_ACC_PUBLIC)
	ZEND_FE_END
};
